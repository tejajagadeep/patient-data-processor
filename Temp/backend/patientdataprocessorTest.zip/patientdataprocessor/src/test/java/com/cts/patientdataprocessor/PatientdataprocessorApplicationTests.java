package com.cts.patientdataprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientdataprocessorApplicationTests {

	@Test
	void contextLoads() {
	}

}

