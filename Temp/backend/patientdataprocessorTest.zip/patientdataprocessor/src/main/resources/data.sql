
insert into patient(contact_number,address,first_name,last_name,gender,date_of_birth,marital_status,emergency_contact_number,email,blood_group,disease,diagnosis,previous_diagnosis,date_visited,treatment_start_date,treatment_end_date,prescription,height,weight)
	values(7894561230,'hyderabad','Rakel','Ramesh','Male','1999-05-28','single',7894561231,'ramesh@gmail.com','O+','High BP','','','2022-11-28','2021-11-28','2023-11-28','Diuretics','170cms','75kgs');

insert into patient(contact_number,address,first_name,last_name,gender,date_of_birth,marital_status,emergency_contact_number,email,blood_group,disease,diagnosis,previous_diagnosis,date_visited,treatment_start_date,treatment_end_date,prescription,height,weight)
	values(9977055233,'Rajamundry','Lavanya','Jampa','Female','1978-08-21','Maried',7093761871,'lavanyajampa@gmail.com','A-','Cardiomyopathy Prophlaxis','Suffering from Cardiomyopathy','','2022-10-12','2021-12-28','2023-10-21','Zinecard','165cms','82kgs');
	
insert into patient(contact_number,address,first_name,last_name,gender,date_of_birth,marital_status,emergency_contact_number,email,blood_group,disease,diagnosis,previous_diagnosis,date_visited,treatment_start_date,treatment_end_date,prescription,height,weight)
	values(6281369288,'Bhimavaram','Kishore','Das','Male','1991-08-01','Maried',6303843351,'kishoredas@gmail.com','B+','Diabetes','','','2022-11-11','2020-06-14','2024-12-28','Lantus','178cms','70kgs');	
	
insert into patient(contact_number,address,first_name,last_name,gender,date_of_birth,marital_status,emergency_contact_number,email,blood_group,disease,diagnosis,previous_diagnosis,date_visited,treatment_start_date,treatment_end_date,prescription,height,weight)
	values(9381058211,'Tanuku','Pushkar','Gupta','Male','1988-08-21','Maried',8381230113,'pushkargupta@gmail.com','A-','High Cholesterol','','','2022-11-28','2022-10-27','2025-10-16','Praluent','168cms','89kgs');	
	
insert into patient(contact_number,address,first_name,last_name,gender,date_of_birth,marital_status,emergency_contact_number,email,blood_group,disease,diagnosis,previous_diagnosis,date_visited,treatment_start_date,treatment_end_date,prescription,height,weight)
	values(9993885348,'Rajamundry','Mahesh','Kankatala','Male','1998-08-21','single',9963549497,'Maheshk@gmail.com','AB-','Constipation','','','2022-10-20','2021-11-02','2023-07-11','MiraLax','180cms','83kgs');	
	
insert into patient(contact_number,address,first_name,last_name,gender,date_of_birth,marital_status,emergency_contact_number,email,blood_group,disease,diagnosis,previous_diagnosis,date_visited,treatment_start_date,treatment_end_date,prescription,height,weight)
	values(9762534308,'Vijaywada','Atmaram','Rao','Male','1995-07-11','Maried',9893561731,'atmaram@gmail.com','A+','High BP','','','2022-11-22','2021-11-22','2023-06-20','Diuretics','175cms','75kgs');

	
	