package com.cts.patientdataprocessor.model;

import java.util.Date; 
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//@Getter
//@Setter
@Entity
@Table
public class Patient {

	@Id
	private long contactNumber;

	private String address;

	private String firstName;

	private String lastName;

	private String gender;

	private Date dateOfBirth;

	private String maritalStatus;

//	private String additioanlNote;

	private Long emergencyContactNumber;

	private String email;

	private String bloodGroup;

//	private String Bpcheck;

//	private String bloodSugarLvls;

	private String disease;

	private String diagnosis;

	@Size(max = 500)
	private String previousDiagnosis;

	private Date dateVisited;

	private Date treatmentStartDate;

	private Date treatmentEndDate;

	private String prescription;

//	private String reports;

	private String height;

	private String weight;

	
	public Patient() {
		super();
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public Long getEmergencyContactNumber() {
		return emergencyContactNumber;
	}

	public void setEmergencyContactNumber(Long emergencyContactNumber) {
		this.emergencyContactNumber = emergencyContactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getDisease() {
		return disease;
	}

	public void setDisease(String disease) {
		this.disease = disease;
	}

	public String getDiagnosis() {
		return diagnosis;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

	public String getPreviousDiagnosis() {
		return previousDiagnosis;
	}

	public void setPreviousDiagnosis(String previousDiagnosis) {
		this.previousDiagnosis = previousDiagnosis;
	}

	public Date getDateVisited() {
		return dateVisited;
	}

	public void setDateVisited(Date dateVisited) {
		this.dateVisited = dateVisited;
	}

	public Date getTreatmentStartDate() {
		return treatmentStartDate;
	}

	public void setTreatmentStartDate(Date treatmentStartDate) {
		this.treatmentStartDate = treatmentStartDate;
	}

	public Date getTreatmentEndDate() {
		return treatmentEndDate;
	}

	public void setTreatmentEndDate(Date treatmentEndDate) {
		this.treatmentEndDate = treatmentEndDate;
	}

	public String getPrescription() {
		return prescription;
	}

	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	
//	public Patient(long contactNumber, String address, String firstName, String lastName, String gender,
//			Date dateOfBirth, String maritalStatus, Long emergencyContactNumber, String email, String bloodGroup,
//			String disease, String diagnosis, @Size(max = 500) String previousDiagnosis, Date dateVisited,
//			Date treatmentStartDate, Date treatmentEndDate, String prescription, String height, String weight) {
//		super();
//		this.contactNumber = contactNumber;
//		this.address = address;
//		this.firstName = firstName;
//		this.lastName = lastName;
//		this.gender = gender;
//		this.dateOfBirth = dateOfBirth;
//		this.maritalStatus = maritalStatus;
//		this.emergencyContactNumber = emergencyContactNumber;
//		this.email = email;
//		this.bloodGroup = bloodGroup;
//		this.disease = disease;
//		this.diagnosis = diagnosis;
//		this.previousDiagnosis = previousDiagnosis;
//		this.dateVisited = dateVisited;
//		this.treatmentStartDate = treatmentStartDate;
//		this.treatmentEndDate = treatmentEndDate;
//		this.prescription = prescription;
//		this.height = height;
//		this.weight = weight;
//	}



	

//	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//	@JoinColumn(name = "contact_number")
//	private Set<Report> reports;
//
//	public void addReports(Report theReport) {
//
//		if (reports == null) {
////			storyAssignedToUsers = new ArrayList<>();
//			reports = new HashSet<>();
//		}
//
//		reports.add(theReport);
//
//	}
}
